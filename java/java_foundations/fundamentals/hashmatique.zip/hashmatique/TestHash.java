package hashmatique;
import java.util.HashMap;

public class TestHash {
    public static void main(String[] args){
        SongTable trackList = new SongTable();
        trackList.trackList();
    }
}
