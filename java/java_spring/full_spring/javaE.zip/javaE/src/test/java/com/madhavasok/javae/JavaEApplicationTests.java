package com.madhavasok.javae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaEApplicationTests {

	@Test
	void contextLoads() {
	}

}
