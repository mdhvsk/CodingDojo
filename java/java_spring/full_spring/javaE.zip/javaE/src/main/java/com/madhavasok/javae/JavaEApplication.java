package com.madhavasok.javae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaEApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaEApplication.class, args);
	}

}
